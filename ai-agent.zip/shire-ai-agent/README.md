# Shire AI Agent (Databricks)

## Run as a Notebook Task
1. Import this repo into Databricks Repos.
2. Open `notebooks/Run_Shire_Agent.py`.
3. Add job widgets: `input_path`, `out_dir`, `formats`.
4. Create a Job → Task: Notebook. Point it at the notebook. Configure a cluster (no GPU required).

## Run as a Wheel Task
1. Build and upload the wheel:
   ```bash
   pip install build
   python -m build
   # Upload dist/*.whl to DBFS or a workspace File and reference from a Job → Python Wheel task
   ```
2. In the Job → Python wheel task, set `Entry point` to `shire-agent` (from `pyproject.toml`).
3. Add task parameters: `--input /dbfs/tmp/shire/sample.csv --out /dbfs/tmp/shire/out --format yaml json`.

## Secrets
- Option 1: Set environment variable `OPENAI_API_KEY` at the Job’s cluster level.
- Option 2: Store in Databricks Secrets and the code will read `default/OPENAI_API_KEY` automatically.

## Outputs
Artifacts are written to `out_dir` (default `/dbfs/tmp/shire/out`):
- `plan-<id>.yaml|json`
- `kb-<id>.json`
- `coordinator-<id>.json`

## Notes
- The `planner` currently uses a deterministic fallback; wire your OpenAI/LangGraph logic in `llm/planner.py`.
- `dnf` isn’t available on many Databricks clusters; the wrapper returns `None` without failing.
