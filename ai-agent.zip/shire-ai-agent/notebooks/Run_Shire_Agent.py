# Databricks notebook entrypoint (use in a Repo or as a Job notebook task)

# Parameters when used as a Job task
# widgets.text("input_path", "/dbfs/tmp/shire/sample.csv")
# widgets.text("out_dir", "/dbfs/tmp/shire/out")
# widgets.text("formats", "yaml,json")

from shire_agent.orchestrator import run

input_path = dbutils.widgets.get("input_path") if "widgets" in dir(dbutils) else "/dbfs/tmp/shire/sample.csv"
out_dir = dbutils.widgets.get("out_dir") if "widgets" in dir(dbutils) else "/dbfs/tmp/shire/out"
formats = dbutils.widgets.get("formats") if "widgets" in dir(dbutils) else "yaml,json"

exit_code = run(input_path=input_path, out_dir=out_dir, formats=[f.strip() for f in formats.split(",") if f])

# If used in a multi-task job, you can signal failure by raising on non-zero code
assert exit_code == 0, f"Run failed with code {exit_code}"
