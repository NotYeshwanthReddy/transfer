from __future__ import annotations
from typing import Any, Dict, List
try:
    from ..legacy import call_legacy  # optional
except Exception:
    call_legacy = None  # type: ignore

class Planner:
    """LLM-backed planner with optional legacy integration and deterministic fallback.

    Priority:
    1) If a legacy function like `generate_plan(row)` exists in your uploaded module, use it.
    2) Else if an API key is configured, call your LLM (stub here).
    3) Else use a clear, deterministic fallback plan.
    """

    def __init__(self, model: str, api_key: str | None) -> None:
        self.model = model
        self.api_key = api_key
        self.use_llm = bool(api_key)

    def plan(self, row: Dict[str, Any]) -> List[str]:
        # 1) Try legacy module if present
        if call_legacy is not None:
            try:
                out = call_legacy(row)
                if out:
                    return out
            except Exception:
                pass

        # 2) LLM path (replace with your integration)
        if self.use_llm:
            return [
                f"(LLM) Review package {row.get('package')}",
                "(LLM) Gather vendor advisories",
                "(LLM) Produce remediation steps",
            ]

        # 3) Deterministic fallback
        steps = [f"Investigate package {row.get('package')}"]
        if row.get("version"):
            steps.append(f"Check CVEs affecting version {row['version']}")
        return steps
