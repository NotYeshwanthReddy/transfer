from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, Optional
import requests

class RedHatCVRF:
    """Download and cache Red Hat CVRF advisories.

    - Allows offline runs by caching responses
    - Gracefully handles 404s (returns None)
    """

    def __init__(self, base_url: str, cache_dir: str | Path):
        self.base_url = base_url.rstrip("/") + "/"
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def fetch(self, advisory: str) -> Optional[Dict[str, Any]]:
        cache_path = self.cache_dir / f"{advisory}.json"
        if cache_path.exists():
            return json.loads(cache_path.read_text())
        url = f"{self.base_url}{advisory}.json"
        r = requests.get(url, timeout=15)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        cache_path.write_text(r.text)
        return r.json()
