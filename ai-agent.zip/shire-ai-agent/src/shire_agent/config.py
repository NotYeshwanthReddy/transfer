from __future__ import annotations
from pydantic import BaseSettings, Field
from typing import Optional

# Helper for Databricks secrets (works locally too)
def _get_secret(scope: str, key: str) -> Optional[str]:
    try:  # Databricks notebook or job context
        from pyspark.dbutils import DBUtils  # type: ignore
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        dbutils = DBUtils(spark)
        return dbutils.secrets.get(scope=scope, key=key)
    except Exception:
        try:
            import builtins
            dbutils = getattr(builtins, "dbutils", None)
            if dbutils:
                return dbutils.secrets.get(scope=scope, key=key)
        except Exception:
            pass
    return None

class Settings(BaseSettings):
    # Core
    output_dir: str = Field(
        default="/dbfs/tmp/shire/out", description="Where artifacts are written"
    )

    # LLM
    openai_api_key: Optional[str] = None
    shire_model: str = Field(default="gpt-4o-mini", description="Model name")

    # Networking / external
    redhat_cvrf_base: str = Field(
        default="https://access.redhat.com/security/data/cvrf/",
        description="Base URL for CVRF feeds",
    )

    # Execution
    fail_fast: bool = Field(default=False, description="Stop on first error")

    class Config:
        env_prefix = "SHIRE_"
        env_file = ".env"

    @classmethod
    def from_env_or_databricks(cls) -> "Settings":
        s = cls()  # Load from env/.env by default
        if not s.openai_api_key:
            # Optionally pull from Databricks secrets
            secret = _get_secret(scope="default", key="OPENAI_API_KEY")
            if secret:
                s.openai_api_key = secret
        return s

# Export a singleton settings object
settings = Settings.from_env_or_databricks()
