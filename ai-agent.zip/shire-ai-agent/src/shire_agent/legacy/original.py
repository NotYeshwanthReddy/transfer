#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures
# ----------------
@dataclass
class NormalizedRow:
    asset: str
    env: Optional[str] = None
    platform: Optional[str] = None
    vuln_name: str = ""
    solution_text: str = ""
    owner_hint: Optional[str] = None
    sox: Optional[bool] = None
    raw: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Verification:
    status: str  # "passed" | "failed"
    reason: Optional[str] = None
    advisory_id: Optional[str] = None
    fixed_nvras: List[str] = field(default_factory=list)
    repo_latest: Optional[str] = None
    meets_or_exceeds_fixed: Optional[bool] = None
    advisory_url: Optional[str] = None
    api_url: Optional[str] = None
    fetched_at_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"))
    payload_sha256: Optional[str] = None

@dataclass
class Plan:
    plan_id: str
    asset: str
    env: Optional[str]
    platform: Optional[str]
    vulnerability: Dict[str, Any]
    owner: str
    action_type: str
    component: str
    target: Dict[str, Any]
    precheck: List[str]
    steps: List[str]
    postcheck: List[str]
    reboot_required: bool
    verification: Verification
    ticket_text: str
    coordinator_event: Dict[str, Any]

# ------------------------
# Header normalization
# ------------------------
COLUMN_ALIASES = {
    "asset": ["asset", "asset name", "hostname", "host", "server"],
    "env": ["env", "environment"],
    "platform": ["platform", "os", "operating system"],
    "vuln_name": ["vuln name", "vulnerability", "vulnerability name", "name"],
    "solution_text": ["solution", "solution text", "remediation", "fix"],
    "owner_hint": ["owner", "treatment owner", "team", "treatment_owner"],
    "sox": ["sox", "sox indicator", "sox_indicator"],
}

def _normalize_header_map(headers: List[str]) -> Dict[str, str]:
    """
    Build a mapping from normalized keys -> actual column names (case-insensitive).
    """
    lower_map = {h.lower().strip(): h for h in headers}
    out: Dict[str, str] = {}
    for norm, aliases in COLUMN_ALIASES.items():
        for a in aliases:
            if a in lower_map:
                out[norm] = lower_map[a]
                break
    return out

def _to_bool_maybe(v: Any) -> Optional[bool]:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"true", "yes", "y", "1"}: return True
    if s in {"false", "no", "n", "0"}: return False
    return None

def _to_str(x: Any) -> Optional[str]:
    if x is None: return None
    s = str(x).strip()
    return s if s != "" else None

# ------------------------
# Input loader (CSV/Excel/JSON)
# ------------------------
def load_input(path: Path) -> List[NormalizedRow]:
    if not path.exists():
        raise FileNotFoundError(path)
    ext = path.suffix.lower()
    rows: List[Dict[str, Any]] = []

    if ext in {".xlsx", ".xls"}:
        if pd is None:
            raise RuntimeError("pandas is required to read Excel files")
        df = pd.read_excel(path)
    elif ext == ".csv":
        if pd is not None:
            df = pd.read_csv(path)
        else:
            # csv fallback without pandas
            with path.open(newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            df = None  # handled separately
    elif ext == ".json":
        # Supports array-of-objects or {"rows":[...]}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "rows" in data:
                rows = data["rows"]
            elif isinstance(data, list):
                rows = data
            else:
                rows = [data]
            df = None
        except Exception as e:
            raise ValueError(f"Invalid JSON input: {e}")
    else:
        raise ValueError(f"Unsupported input type: {ext}")

    if df is not None:
        src_rows = df.to_dict(orient="records")
    else:
        src_rows = rows

    if not src_rows:
        return []

    # Build alias map from the *original* column names
    headers = list(df.columns) if df is not None else list(src_rows[0].keys())
    header_map = _normalize_header_map([str(h) for h in headers])

    required = ["asset", "env", "platform", "vuln_name", "solution_text", "owner_hint", "sox"]
    missing = [k for k in required if k not in header_map]
    if missing:
        raise KeyError(
            "Missing expected columns: "
            + ", ".join(missing)
            + f"\nSeen columns: {headers}"
            + "\nTip: include aliases like 'Asset Name', 'ENV', 'Platform', 'Vulnerability', 'Solution', 'Treatment Owner', 'SOX Indicator'."
        )

    normed: List[NormalizedRow] = []
    for r in src_rows:
        def g(key: str) -> Any:
            src = header_map.get(key)
            return r.get(src) if src else None

        normed.append(
            NormalizedRow(
                asset=_to_str(g("asset")) or "",
                env=_to_str(g("env")),
                platform=_to_str(g("platform")),
                vuln_name=_to_str(g("vuln_name")) or "",
                solution_text=_to_str(g("solution_text")) or "",
                owner_hint=_to_str(g("owner_hint")),
                sox=_to_bool_maybe(g("sox")),
                raw=r,
            )
        )
    return normed

# ------------------------
# KB Retriever (allowlisted)
# ------------------------
class KBRetriever:
    def __init__(self, allow_network: bool = True) -> None:
        self.allow_network = allow_network

    def fetch_redhat(self, rhsa: str) -> Tuple[Optional[dict], Optional[str]]:
        if not self.allow_network or requests is None:
            return None, None
        url = TRUSTED["redhat_cvrf"].format(rhsa=rhsa)
        try:
            resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=DEFAULT_TIMEOUT_S)
            if resp.status_code == 404:
                logging.warning("Advisory %s not found (404); continuing without KB.", rhsa)
                return None, None
            resp.raise_for_status()
            sha = __import__("hashlib").sha256(resp.content).hexdigest()
            try:
                return resp.json(), sha
            except Exception:
                return None, sha
        except Exception as e:  # pragma: no cover
            logging.warning("KB fetch failed for %s: %s", rhsa, e)
            return None, None

    @staticmethod
    def extract_fixed_nvras(cvrf: dict, component: str, os_release: str = "8") -> List[str]:
        if not cvrf:
            return []
        texts: List[str] = []

        def walk(x: Any) -> None:
            if isinstance(x, dict):
                for v in x.values(): walk(v)
            elif isinstance(x, list):
                for v in x: walk(v)
            elif isinstance(x, str):
                if component in x or f"el{os_release}" in x or "noarch" in x:
                    texts.append(x)
        walk(cvrf)

        rx = re.compile(rf"\b({re.escape(component)})-([0-9][\w\.\+~:-]*)\.el{re.escape(os_release)}\.(\w+)\b")
        out: List[str] = []
        seen = set()
        for t in texts:
            for m in rx.finditer(t):
                nvra = m.group(0)
                if nvra not in seen:
                    out.append(nvra)
                    seen.add(nvra)
        return out

# ------------------------
# Repo check (dnf)
# ------------------------
class RepoChecker:
    @staticmethod
    def repoquery_cmd(component: str) -> str:
        # Escape braces so .format() doesn't try to interpolate %{name}
        return "dnf repoquery --qf '%{{name}}-%{{version}}-%{{release}}.%{{arch}}' {} --latest-limit 1".format(component)

    def check_latest(self, component: str) -> Tuple[bool, Optional[str]]:
        # If dnf not present (macOS/Windows), skip gracefully
        if shutil.which("dnf") is None:
            logging.warning("dnf not found on this host; skipping repo query for %s", component)
            return False, None
        cmd = self.repoquery_cmd(component)
        try:
            p = subprocess.run(cmd, shell=True, text=True, capture_output=True, timeout=DEFAULT_TIMEOUT_S)
            if p.returncode != 0:
                logging.warning("repoquery failed %s: %s", p.returncode, p.stderr.strip())
                return False, None
            lines = (p.stdout or "").strip().splitlines()
            return (len(lines) > 0), (lines[0] if lines else None)
        except Exception as e:  # pragma: no cover
            logging.warning("repoquery exception: %s", e)
            return False, None

    @staticmethod
    def meets_or_exceeds(latest: str, fixed_list: List[str]) -> bool:
        def split_nvra(s: str) -> Tuple[str, str, str]:
            m = re.match(r"^([^-]+)-(\S+)\.(\w+)$", s)
            return (m.group(1), m.group(2), m.group(3)) if m else (s, s, "noarch")
        if not latest:
            return False
        lname, lverrel, _ = split_nvra(latest)
        for fx in fixed_list or []:
            fname, fverrel, _ = split_nvra(fx)
            if fname != lname:
                continue
            if latest == fx:
                return True
            # Lexical fallback; in production, use rpm labelCompare if available
            if lverrel >= fverrel:
                return True
        return False

# ------------------------
# AI Planner (LLM)
# ------------------------
PLANNER_SYS_PROMPT = (
    "You are a Linux remediation planner for a regulated bank. "
    "Given a vulnerability row, verified advisory facts (KB), and repo state, "
    "produce a deterministic patch plan for RHEL 8 Python setuptools packages. "
    "STRICT RULES: (1) Do not invent package names; use the component provided. "
    "(2) Prefer dnf with --security and the advisory id if present. "
    "(3) Reboot only if needs-restart -r indicates or kernel/glibc updated. "
    "(4) Include precheck, steps, postcheck. (5) Owner = row.owner_hint or TI – AIX/UNIX Team. "
    "Output as JSON with keys: precheck, steps, postcheck, reboot_required, target_description, ticket_note."
)

class AIPlanner:
    def __init__(self, model: str = DEFAULT_MODEL, temperature: Optional[float] = 0.0) -> None:
        # Some 'gpt-4o' models reject explicit temperature; omit for those models
        self.model = model
        self.pass_temperature = (temperature is not None) and ("gpt-4o" not in (model or "").lower())
        self.temperature = temperature if self.pass_temperature else None
        if OpenAI is None or not os.getenv("OPENAI_API_KEY"):
            self.client = None
        else:
            self.client = OpenAI()

    def plan(self, row: NormalizedRow, component: str, rhsa: Optional[str],
             kb_nvras: List[str], repo_latest: Optional[str]) -> Dict[str, Any]:
        """
        Call the LLM with strict system prompt + compact context.
        Fallback to deterministic plan if LLM unavailable or API rejects params.
        """
        ctx = {
            "asset": row.asset,
            "env": row.env,
            "component": component,
            "rhsa": rhsa,
            "kb_fixed_nvras": kb_nvras,
            "repo_latest": repo_latest,
            "vuln_name": row.vuln_name,
            "solution_text": row.solution_text,
            "owner": row.owner_hint or "TI – AIX/UNIX Team",
        }

        if self.client is None:
            logging.warning("OpenAI not available; using deterministic fallback plan")
            return self._fallback(ctx)

        try:
            kwargs = {
                "model": self.model,
                "messages": [
                    {"role": "system", "content": PLANNER_SYS_PROMPT},
                    {"role": "user", "content": json.dumps(ctx)},
                ],
                "response_format": {"type": "json_object"},
            }
            if self.pass_temperature and self.temperature is not None:
                kwargs["temperature"] = self.temperature

            msg = self.client.chat.completions.create(**kwargs)
            content = msg.choices[0].message.content  # type: ignore[attr-defined]
            data = json.loads(content)
            return self._coerce(data, ctx)
        except Exception as e:  # pragma: no cover
            logging.error("LLM planning failed: %s", e)
            return self._fallback(ctx)

    @staticmethod
    def _coerce(data: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
        def ensure_list(x: Any) -> List[str]:
            return [str(i) for i in x] if isinstance(x, list) else [str(x)] if isinstance(x, str) else []
        pre = ensure_list(data.get("precheck")) or [
            rf"rpm -qa | egrep '^{re.escape(ctx['component'])}' || true",
            "dnf check-update --security || true",
            "pgrep -a python || true",
        ]
        steps = ensure_list(data.get("steps")) or [
            f"dnf update -y --security{(' --advisory='+ctx['rhsa']) if ctx.get('rhsa') else ''} {ctx['component']}",
        ]
        post = ensure_list(data.get("postcheck")) or [
            f"rpm -q {ctx['component']} --qf '%{{NAME}}-%{{VERSION}}-%{{RELEASE}}.%{{ARCH}}\\n'",
            "needs-restart -r || true",
        ]
        reboot = bool(data.get("reboot_required", False))
        target = str(data.get("target_description") or (
            f"Install the {ctx['rhsa']} fixed build (or newer) from approved repo" if ctx.get("rhsa") else
            "Install the latest security-fixed build from approved repo"
        ))
        note = str(data.get("ticket_note") or "Python setuptools security update per advisory")
        return {"precheck": pre, "steps": steps, "postcheck": post, "reboot_required": reboot, "target": target, "ticket_note": note}

    @staticmethod
    def _fallback(ctx: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "precheck": [
                rf"rpm -qa | egrep '^{re.escape(ctx['component'])}' || true",
                "dnf check-update --security || true",
                "pgrep -a python || true",
            ],
            "steps": [
                f"dnf update -y --security{(' --advisory='+ctx['rhsa']) if ctx.get('rhsa') else ''} {ctx['component']}",
            ],
            "postcheck": [
                f"rpm -q {ctx['component']} --qf '%{{NAME}}-%{{VERSION}}-%{{RELEASE}}.%{{ARCH}}\\n'",
                "needs-restart -r || true",
            ],
            "reboot_required": False,
            "target": (
                f"Install the {ctx['rhsa']} fixed build (or newer) from approved repo" if ctx.get("rhsa") else
                "Install the latest security-fixed build from approved repo"
            ),
            "ticket_note": "Deterministic fallback plan (LLM unavailable)",
        }

# ------------------------
# Orchestrator
# ------------------------
DEFAULT_OWNER_OS = "TI – AIX/UNIX Team"
SETUPTOOLS_PATTERNS = [
    (re.compile(r"python3\.11-setuptools", re.I), "python3.11-setuptools"),
    (re.compile(r"python3-setuptools", re.I), "python3-setuptools"),
    (re.compile(r"python-setuptools", re.I), "python-setuptools"),
]
RHSA_RX = re.compile(r"RHSA[-\s:]?\s*(\d{4}:\d{4,5})", re.I)

class Orchestrator:
    def __init__(self, model: str, allow_network: bool) -> None:
        self.kb = KBRetriever(allow_network=allow_network)
        self.repo = RepoChecker()
        self.planner = AIPlanner(model=model)
        self.allow_network = allow_network

    def process_row(self, row: NormalizedRow) -> Plan:
        # 1) classify component + extract RHSA
        component = self._classify_component(row)
        rhsa = self._extract_rhsa(row)

        # 2) KB: fetch RHSA, extract fixed NVRAs
        fixed_nvras: List[str] = []
        payload_sha = None
        advisory_url = TRUSTED["redhat_errata"].format(rhsa=rhsa) if rhsa else None
        api_url = TRUSTED["redhat_cvrf"].format(rhsa=rhsa) if rhsa else None
        if rhsa:
            cvrf, sha = self.kb.fetch_redhat(rhsa)
            payload_sha = sha
            if cvrf:
                fixed_nvras = self.kb.extract_fixed_nvras(cvrf, component, os_release="8")

        # 3) Repo state
        repo_ok, repo_latest = self.repo.check_latest(component)
        meets = self.repo.meets_or_exceeds(repo_latest, fixed_nvras) if (repo_latest and fixed_nvras) else None

        # 4) Verification
        ver = Verification(
            status=("passed" if repo_ok and (meets is True or not fixed_nvras) else "failed"),
            reason=(None if repo_ok and (meets is True or not fixed_nvras) else ("repo_missing_or_older_than_fixed" if repo_ok else "repo_query_failed")),
            advisory_id=rhsa,
            fixed_nvras=fixed_nvras,
            repo_latest=repo_latest,
            meets_or_exceeds_fixed=meets,
            advisory_url=advisory_url,
            api_url=api_url,
            payload_sha256=payload_sha,
        )

        # 5) AI plan (or fallback)
        bits = self.planner.plan(row, component, rhsa, fixed_nvras, repo_latest)

        # 6) Compose plan object
        plan_id = f"PL-{datetime.now(timezone.utc):%Y-%m-%d-%H%M%S}-{abs(hash((row.asset, row.vuln_name))) % 100000:05d}"
        owner = row.owner_hint or DEFAULT_OWNER_OS
        ticket_text = (
            f"Patch {component} on {row.asset} ({row.env or 'ENV-UNKNOWN'}) per {rhsa or 'security errata'}\n"
            f"Action: {bits['steps'][0]}\n"
            f"Owner: {owner} | SOX: {row.sox if row.sox is not None else 'unknown'}\n"
            f"Evidence: fixed NVRA(s): {fixed_nvras or []}; repo_latest: {repo_latest or 'N/A'}\n"
            f"Note: {bits['ticket_note']}"
        )
        coordinator_event = {
            "agent": "VulnerabilityScannerAI",
            "event": "FINDING_READY",
            "correlation_id": plan_id,
            "asset": row.asset,
            "vuln": {"name": row.vuln_name or f"RHEL 8 : {component}", "sox": row.sox},
            "plan": {"action_type": "package_update", "component": component, "reboot_required": bits["reboot_required"]},
            "verification": {"status": ver.status, "advisory_url": ver.advisory_url},
            "links": {"full_plan": f"s3://shire/plans/{plan_id}.yaml", "kb": f"s3://shire/kb/{plan_id}.json"},
        }

        plan = Plan(
            plan_id=plan_id,
            asset=row.asset,
            env=row.env,
            platform=row.platform or "RHEL 8",
            vulnerability={"name": row.vuln_name or f"RHEL 8 : {component}", "sox": bool(row.sox) if row.sox is not None else None},
            owner=owner,
            action_type="package_update",
            component=component,
            target={"description": bits["target"]},
            precheck=bits["precheck"],
            steps=bits["steps"],
            postcheck=bits["postcheck"],
            reboot_required=bool(bits["reboot_required"]),
            verification=ver,
            ticket_text=ticket_text,
            coordinator_event=coordinator_event,
        )
        return plan

    @staticmethod
    def _classify_component(row: NormalizedRow) -> str:
        text = f"{row.vuln_name} {row.solution_text}"
        for rx, pkg in SETUPTOOLS_PATTERNS:
            if rx.search(text):
                return pkg
        return "python-setuptools"  # conservative default

    @staticmethod
    def _extract_rhsa(row: NormalizedRow) -> Optional[str]:
        txt = f"{row.vuln_name} {row.solution_text}"
        m = RHSA_RX.search(txt)
        return f"RHSA-{m.group(1)}" if m else None

# ------------------------
# Orchestration
# ------------------------
def write_yaml_or_json(out_path: Path, data: Dict[str, Any], fmt: str) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "yaml":
        if yaml is None:
            # fallback: write JSON with .yaml extension
            out_path.write_text(json.dumps(data, indent=2))
        else:
            with out_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, sort_keys=False)
    elif fmt == "json":
        out_path.write_text(json.dumps(data, indent=2))
    else:
        raise ValueError(f"Unsupported format: {fmt}")

def process_rows(rows: List[NormalizedRow], model: str, allow_network: bool) -> List[Plan]:
    orch = Orchestrator(model=model, allow_network=allow_network)
    return [orch.process_row(r) for r in rows]

# ------------------------
# CLI
# ------------------------
def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Shire Python Vulnerability Scanner **AI Agent** (standalone)")
    p.add_argument("--input", required=True, help="Path to CSV/Excel/JSON findings file")
    p.add_argument("--out", required=True, help="Output directory")
    p.add_argument("--format", nargs="+", default=["yaml"], choices=["yaml", "json"], help="Output formats")
    p.add_argument("--model", default=DEFAULT_MODEL, help="LLM model (default from SHIRE_MODEL)")
    p.add_argument("--no-network", action="store_true", help="Disable internet KB fetch (uses empty KB)")
    p.add_argument("--log-level", default="INFO")
    return p.parse_args(argv)

def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=getattr(logging, args.log_level.upper(), logging.INFO), format="%(levelname)s %(message)s")

    in_path = Path(args.input)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = load_input(in_path)
    if not rows:
        logging.warning("No rows in input.")
        return 0

    plans = process_rows(rows, model=args.model, allow_network=not args.no_network)

    for p in plans:
        plan_dict = asdict(p)
        kb_doc = {
            "kb": {
                "title": p.vulnerability.get("name"),
                "advisory": {
                    "id": p.verification.advisory_id,
                    "url": p.verification.advisory_url,
                    "api_url": p.verification.api_url,
                    "fixed_nvras": p.verification.fixed_nvras,
                },
                "evidence": {
                    "fetched_at_utc": p.verification.fetched_at_utc,
                    "payload_sha256": p.verification.payload_sha256,
                },
            }
        }
        coord_doc = p.coordinator_event

        for fmt in args.format:
            write_yaml_or_json(out_dir / f"plan-{p.plan_id}.{fmt}", plan_dict, fmt)
        write_yaml_or_json(out_dir / f"kb-{p.plan_id}.json", kb_doc, "json")
        write_yaml_or_json(out_dir / f"coordinator-{p.plan_id}.json", coord_doc, "json")
        logging.info("Wrote plan %s", p.plan_id)

    logging.info("Done. %d plan(s) generated.", len(plans))
    return 0

if __name__ == "__main__":
    # It's okay if OPENAI_API_KEY is not set — the agent will fallback to deterministic planning
    sys.exit(main())