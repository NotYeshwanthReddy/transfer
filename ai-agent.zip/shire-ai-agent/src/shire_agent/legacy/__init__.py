# Adapters to call user's legacy logic when present.
from __future__ import annotations
from typing import Any, Dict, List, Callable, Optional
import types

def _pick_callable(mod: types.ModuleType) -> Optional[Callable[[Dict[str, Any]], List[str]]]:
    """Try common function names that accept a single row dict and return steps."""
    candidates = ["generate_plan", "plan", "build_plan", "make_plan"]
    for name in candidates:
        fn = getattr(mod, name, None)
        if callable(fn):
            return fn  # type: ignore[return-value]
    return None

def call_legacy(row: Dict[str, Any]) -> Optional[List[str]]:
    try:
        from . import original as legacy_mod  # type: ignore
    except Exception:
        return None
    fn = _pick_callable(legacy_mod)
    if fn is None:
        return None
    try:
        res = fn(row)  # type: ignore[arg-type]
        if isinstance(res, list) and all(isinstance(x, str) for x in res):
            return res  # type: ignore[return-value]
    except Exception:
        return None
    return None
