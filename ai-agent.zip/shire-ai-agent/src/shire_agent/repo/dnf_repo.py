from __future__ import annotations
import shutil
import subprocess
from typing import Optional

class DnfRepo:
    """Thin wrapper over `dnf repoquery`.

    On machines without dnf (e.g., Databricks clusters), calls are skipped
    and return None instead of failing the whole run.
    """

    def __init__(self) -> None:
        self.available = shutil.which("dnf") is not None

    def is_available(self) -> bool:
        return self.available

    def repoquery(self, package: str) -> Optional[str]:
        if not self.available:
            return None
        try:
            out = subprocess.check_output(["dnf", "repoquery", package], text=True, timeout=20)
            return out.strip()
        except Exception:
            return None
