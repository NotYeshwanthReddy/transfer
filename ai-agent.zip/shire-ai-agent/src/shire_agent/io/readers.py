from __future__ import annotations
import csv
from pathlib import Path
from typing import Iterable, List

try:  # optional dependency
    import pandas as pd  # type: ignore
except Exception:  # pragma: no cover
    pd = None

from ..models import InputRow

ALIASES = {
    "pkg": "package",
    "name": "package",
    "pkg_name": "package",
}

def _normalize_headers(cols: List[str]) -> List[str]:
    return [ALIASES.get(c.strip().lower(), c.strip()) for c in cols]

def load_rows(path: str | Path) -> Iterable[InputRow]:
    p = Path(path)
    ext = p.suffix.lower()
    if ext in {".xlsx", ".xls"}:
        if pd is None:
            raise RuntimeError("pandas is required to read Excel files")
        df = pd.read_excel(p)
        df.columns = _normalize_headers([str(c) for c in df.columns])
        for rec in df.to_dict(orient="records"):
            yield InputRow(**rec)
    elif ext == ".csv":
        if pd is not None:
            df = pd.read_csv(p)
            df.columns = _normalize_headers([str(c) for c in df.columns])
            for rec in df.to_dict(orient="records"):
                yield InputRow(**rec)
        else:
            with p.open(newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                reader.fieldnames = _normalize_headers(reader.fieldnames or [])
                for rec in reader:
                    yield InputRow(**rec)
    elif ext == ".json":
        import json
        data = json.loads(p.read_text())
        rows = data["rows"] if isinstance(data, dict) and "rows" in data else data
        for rec in rows:
            yield InputRow(**rec)
    else:
        raise ValueError(f"Unsupported input format: {ext}")
