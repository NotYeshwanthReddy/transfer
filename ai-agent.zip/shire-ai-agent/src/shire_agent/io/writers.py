from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict

import yaml  # pyyaml

FMT_JSON = "json"
FMT_YAML = "yaml"

def write_artifact(base_dir: str | Path, name: str, data: Dict[str, Any], fmt: str) -> str:
    out = Path(base_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}.{fmt}"
    if fmt == FMT_JSON:
        path.write_text(json.dumps(data, indent=2, sort_keys=True))
    elif fmt == FMT_YAML:
        path.write_text(yaml.safe_dump(data, sort_keys=False))
    else:
        raise ValueError("fmt must be 'json' or 'yaml'")
    return str(path)
