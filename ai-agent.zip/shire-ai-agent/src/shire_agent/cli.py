from __future__ import annotations
import argparse
from .orchestrator import run

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Run Shire AI Agent")
    p.add_argument("--input", required=True, help="Input file (.csv/.xlsx/.json)")
    p.add_argument("--out", default=None, help="Output directory (DBFS path ok)")
    p.add_argument("--format", nargs="*", default=["yaml", "json"], help="One or more: yaml json")
    return p

def main() -> int:
    args = build_parser().parse_args()
    return run(input_path=args.input, out_dir=args.out, formats=args.format)
