from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime

class InputRow(BaseModel):
    # A normalized representation of a software finding row
    package: str
    version: Optional[str] = None
    os: Optional[str] = None
    arch: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class PlanArtifact(BaseModel):
    plan_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    steps: List[str]
    kb: Dict[str, Any]
    coordinator_event: Dict[str, Any]
