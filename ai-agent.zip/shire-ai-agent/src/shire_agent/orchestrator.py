from __future__ import annotations
from typing import List
from datetime import datetime
import logging
from .config import settings
from .logging_utils import setup_logging
from .io.readers import load_rows
from .io.writers import write_artifact, FMT_JSON, FMT_YAML
from .llm.planner import Planner
from .cve.redhat_cvrf import RedHatCVRF
from .repo.dnf_repo import DnfRepo
from .models import PlanArtifact

def run(input_path: str, out_dir: str | None = None, formats: List[str] | None = None) -> int:
    """End-to-end driver used by both CLI and Databricks notebook.

    - Loads input rows
    - For each row, builds a plan (LLM or fallback)
    - Optionally enriches with CVRF and repo data
    - Writes per-plan artifacts (yaml/json)
    """
    out = out_dir or settings.output_dir
    formats = formats or [FMT_YAML, FMT_JSON]

    setup_logging(log_to_file=True, out_dir=out)
    log = logging.getLogger("shire.run")

    planner = Planner(model=settings.shire_model, api_key=settings.openai_api_key)
    cvrf = RedHatCVRF(base_url=settings.redhat_cvrf_base, cache_dir=f"{out}/cache/cvrf")
    dnf = DnfRepo()

    count = 0
    for row in load_rows(input_path):
        # Build plan steps
        steps = planner.plan(row.dict())

        # Example enrichments (placeholder)
        kb = {"cvrf": None, "repo": None}
        # kb["cvrf"] = cvrf.fetch("RHSA-2024:0001")  # if you map packages → advisories
        kb["repo"] = dnf.repoquery(row.package)

        artifact = PlanArtifact(
            plan_id=f"{row.package}-{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}",
            steps=steps,
            kb=kb,
            coordinator_event={"package": row.package, "ts": datetime.utcnow().isoformat()},
        )

        # Persist artifacts
        as_dict = artifact.dict()
        for fmt in formats:
            write_artifact(out, f"plan-{artifact.plan_id}", as_dict, fmt)
        write_artifact(out, f"kb-{artifact.plan_id}", artifact.kb, FMT_JSON)
        write_artifact(out, f"coordinator-{artifact.plan_id}", artifact.coordinator_event, FMT_JSON)

        log.info("Wrote plan %s", artifact.plan_id)
        count += 1

    log.info("Done. %d plan(s) generated.", count)
    return 0
