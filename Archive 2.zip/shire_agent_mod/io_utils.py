#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures

COLUMN_ALIASES = {
    "asset": ["asset", "asset name", "hostname", "host", "server"],
    "env": ["env", "environment"],
    "platform": ["platform", "os", "operating system"],
    "vuln_name": ["vuln name", "vulnerability", "vulnerability name", "name"],
    "solution_text": ["solution", "solution text", "remediation", "fix"],
    "owner_hint": ["owner", "treatment owner", "team", "treatment_owner"],
    "sox": ["sox", "sox indicator", "sox_indicator"],
}

from .models import NormalizedRow
def _normalize_header_map(headers: List[str]) -> Dict[str, str]:
    """
    Build a mapping from normalized keys -> actual column names (case-insensitive).
    """
    lower_map = {h.lower().strip(): h for h in headers}
    out: Dict[str, str] = {}
    for norm, aliases in COLUMN_ALIASES.items():
        for a in aliases:
            if a in lower_map:
                out[norm] = lower_map[a]
                break
    return out

def _to_bool_maybe(v: Any) -> Optional[bool]:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"true", "yes", "y", "1"}: return True
    if s in {"false", "no", "n", "0"}: return False
    return None

def _to_str(x: Any) -> Optional[str]:
    if x is None: return None
    s = str(x).strip()
    return s if s != "" else None

def load_input(path: Path) -> List[NormalizedRow]:
    if not path.exists():
        raise FileNotFoundError(path)
    ext = path.suffix.lower()
    rows: List[Dict[str, Any]] = []

    if ext in {".xlsx", ".xls"}:
        if pd is None:
            raise RuntimeError("pandas is required to read Excel files")
        df = pd.read_excel(path)
    elif ext == ".csv":
        if pd is not None:
            df = pd.read_csv(path)
        else:
            # csv fallback without pandas
            with path.open(newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            df = None  # handled separately
    elif ext == ".json":
        # Supports array-of-objects or {"rows":[...]}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "rows" in data:
                rows = data["rows"]
            elif isinstance(data, list):
                rows = data
            else:
                rows = [data]
            df = None
        except Exception as e:
            raise ValueError(f"Invalid JSON input: {e}")
    else:
        raise ValueError(f"Unsupported input type: {ext}")

    if df is not None:
        src_rows = df.to_dict(orient="records")
    else:
        src_rows = rows

    if not src_rows:
        return []

    # Build alias map from the *original* column names
    headers = list(df.columns) if df is not None else list(src_rows[0].keys())
    header_map = _normalize_header_map([str(h) for h in headers])

    required = ["asset", "env", "platform", "vuln_name", "solution_text", "owner_hint", "sox"]
    missing = [k for k in required if k not in header_map]
    if missing:
        raise KeyError(
            "Missing expected columns: "
            + ", ".join(missing)
            + f"\nSeen columns: {headers}"
            + "\nTip: include aliases like 'Asset Name', 'ENV', 'Platform', 'Vulnerability', 'Solution', 'Treatment Owner', 'SOX Indicator'."
        )

    normed: List[NormalizedRow] = []
    for r in src_rows:
        def g(key: str) -> Any:
            src = header_map.get(key)
            return r.get(src) if src else None

        normed.append(
            NormalizedRow(
                asset=_to_str(g("asset")) or "",
                env=_to_str(g("env")),
                platform=_to_str(g("platform")),
                vuln_name=_to_str(g("vuln_name")) or "",
                solution_text=_to_str(g("solution_text")) or "",
                owner_hint=_to_str(g("owner_hint")),
                sox=_to_bool_maybe(g("sox")),
                raw=r,
            )
        )
    return normed

def write_yaml_or_json(out_path: Path, data: Dict[str, Any], fmt: str) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "yaml":
        if yaml is None:
            # fallback: write JSON with .yaml extension
            out_path.write_text(json.dumps(data, indent=2))
        else:
            with out_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, sort_keys=False)
    elif fmt == "json":
        out_path.write_text(json.dumps(data, indent=2))
    else:
        raise ValueError(f"Unsupported format: {fmt}")

