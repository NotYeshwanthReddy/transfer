#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures

from .models import *
class RepoChecker:
    @staticmethod
    def repoquery_cmd(component: str) -> str:
        # Escape braces so .format() doesn't try to interpolate %{name}
        return "dnf repoquery --qf '%{{name}}-%{{version}}-%{{release}}.%{{arch}}' {} --latest-limit 1".format(component)

    def check_latest(self, component: str) -> Tuple[bool, Optional[str]]:
        # If dnf not present (macOS/Windows), skip gracefully
        if shutil.which("dnf") is None:
            logging.warning("dnf not found on this host; skipping repo query for %s", component)
            return False, None
        cmd = self.repoquery_cmd(component)
        try:
            p = subprocess.run(cmd, shell=True, text=True, capture_output=True, timeout=DEFAULT_TIMEOUT_S)
            if p.returncode != 0:
                logging.warning("repoquery failed %s: %s", p.returncode, p.stderr.strip())
                return False, None
            lines = (p.stdout or "").strip().splitlines()
            return (len(lines) > 0), (lines[0] if lines else None)
        except Exception as e:  # pragma: no cover
            logging.warning("repoquery exception: %s", e)
            return False, None

    @staticmethod
    def meets_or_exceeds(latest: str, fixed_list: List[str]) -> bool:
        def split_nvra(s: str) -> Tuple[str, str, str]:
            m = re.match(r"^([^-]+)-(\S+)\.(\w+)$", s)
            return (m.group(1), m.group(2), m.group(3)) if m else (s, s, "noarch")
        if not latest:
            return False
        lname, lverrel, _ = split_nvra(latest)
        for fx in fixed_list or []:
            fname, fverrel, _ = split_nvra(fx)
            if fname != lname:
                continue
            if latest == fx:
                return True
            # Lexical fallback; in production, use rpm labelCompare if available
            if lverrel >= fverrel:
                return True
        return False

