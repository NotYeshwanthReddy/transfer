#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures

from .models import *
from .kb import KBRetriever
from .repo import RepoChecker
from .planner import AIPlanner
DEFAULT_OWNER_OS = "TI – AIX/UNIX Team"

RHSA_RX = re.compile(r"RHSA[-\s:]?\s*(\d{4}:\d{4,5})", re.I)

SETUPTOOLS_PATTERNS = [
    (re.compile(r"python3\.11-setuptools", re.I), "python3.11-setuptools"),
    (re.compile(r"python3-setuptools", re.I), "python3-setuptools"),
    (re.compile(r"python-setuptools", re.I), "python-setuptools"),
]

class Orchestrator:
    def __init__(self, model: str, allow_network: bool) -> None:
        self.kb = KBRetriever(allow_network=allow_network)
        self.repo = RepoChecker()
        self.planner = AIPlanner(model=model)
        self.allow_network = allow_network

    def process_row(self, row: NormalizedRow) -> Plan:
        # 1) classify component + extract RHSA
        component = self._classify_component(row)
        rhsa = self._extract_rhsa(row)

        # 2) KB: fetch RHSA, extract fixed NVRAs
        fixed_nvras: List[str] = []
        payload_sha = None
        advisory_url = TRUSTED["redhat_errata"].format(rhsa=rhsa) if rhsa else None
        api_url = TRUSTED["redhat_cvrf"].format(rhsa=rhsa) if rhsa else None
        if rhsa:
            cvrf, sha = self.kb.fetch_redhat(rhsa)
            payload_sha = sha
            if cvrf:
                fixed_nvras = self.kb.extract_fixed_nvras(cvrf, component, os_release="8")

        # 3) Repo state
        repo_ok, repo_latest = self.repo.check_latest(component)
        meets = self.repo.meets_or_exceeds(repo_latest, fixed_nvras) if (repo_latest and fixed_nvras) else None

        # 4) Verification
        ver = Verification(
            status=("passed" if repo_ok and (meets is True or not fixed_nvras) else "failed"),
            reason=(None if repo_ok and (meets is True or not fixed_nvras) else ("repo_missing_or_older_than_fixed" if repo_ok else "repo_query_failed")),
            advisory_id=rhsa,
            fixed_nvras=fixed_nvras,
            repo_latest=repo_latest,
            meets_or_exceeds_fixed=meets,
            advisory_url=advisory_url,
            api_url=api_url,
            payload_sha256=payload_sha,
        )

        # 5) AI plan (or fallback)
        bits = self.planner.plan(row, component, rhsa, fixed_nvras, repo_latest)

        # 6) Compose plan object
        plan_id = f"PL-{datetime.now(timezone.utc):%Y-%m-%d-%H%M%S}-{abs(hash((row.asset, row.vuln_name))) % 100000:05d}"
        owner = row.owner_hint or DEFAULT_OWNER_OS
        ticket_text = (
            f"Patch {component} on {row.asset} ({row.env or 'ENV-UNKNOWN'}) per {rhsa or 'security errata'}\n"
            f"Action: {bits['steps'][0]}\n"
            f"Owner: {owner} | SOX: {row.sox if row.sox is not None else 'unknown'}\n"
            f"Evidence: fixed NVRA(s): {fixed_nvras or []}; repo_latest: {repo_latest or 'N/A'}\n"
            f"Note: {bits['ticket_note']}"
        )
        coordinator_event = {
            "agent": "VulnerabilityScannerAI",
            "event": "FINDING_READY",
            "correlation_id": plan_id,
            "asset": row.asset,
            "vuln": {"name": row.vuln_name or f"RHEL 8 : {component}", "sox": row.sox},
            "plan": {"action_type": "package_update", "component": component, "reboot_required": bits["reboot_required"]},
            "verification": {"status": ver.status, "advisory_url": ver.advisory_url},
            "links": {"full_plan": f"s3://shire/plans/{plan_id}.yaml", "kb": f"s3://shire/kb/{plan_id}.json"},
        }

        plan = Plan(
            plan_id=plan_id,
            asset=row.asset,
            env=row.env,
            platform=row.platform or "RHEL 8",
            vulnerability={"name": row.vuln_name or f"RHEL 8 : {component}", "sox": bool(row.sox) if row.sox is not None else None},
            owner=owner,
            action_type="package_update",
            component=component,
            target={"description": bits["target"]},
            precheck=bits["precheck"],
            steps=bits["steps"],
            postcheck=bits["postcheck"],
            reboot_required=bool(bits["reboot_required"]),
            verification=ver,
            ticket_text=ticket_text,
            coordinator_event=coordinator_event,
        )
        return plan

    @staticmethod
    def _classify_component(row: NormalizedRow) -> str:
        text = f"{row.vuln_name} {row.solution_text}"
        for rx, pkg in SETUPTOOLS_PATTERNS:
            if rx.search(text):
                return pkg
        return "python-setuptools"  # conservative default

    @staticmethod
    def _extract_rhsa(row: NormalizedRow) -> Optional[str]:
        txt = f"{row.vuln_name} {row.solution_text}"
        m = RHSA_RX.search(txt)
        return f"RHSA-{m.group(1)}" if m else None

def process_rows(rows: List[NormalizedRow], model: str, allow_network: bool) -> List[Plan]:
    orch = Orchestrator(model=model, allow_network=allow_network)
    return [orch.process_row(r) for r in rows]

