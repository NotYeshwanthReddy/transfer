#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures

from .models import *
class KBRetriever:
    def __init__(self, allow_network: bool = True) -> None:
        self.allow_network = allow_network

    def fetch_redhat(self, rhsa: str) -> Tuple[Optional[dict], Optional[str]]:
        if not self.allow_network or requests is None:
            return None, None
        url = TRUSTED["redhat_cvrf"].format(rhsa=rhsa)
        try:
            resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=DEFAULT_TIMEOUT_S)
            if resp.status_code == 404:
                logging.warning("Advisory %s not found (404); continuing without KB.", rhsa)
                return None, None
            resp.raise_for_status()
            sha = __import__("hashlib").sha256(resp.content).hexdigest()
            try:
                return resp.json(), sha
            except Exception:
                return None, sha
        except Exception as e:  # pragma: no cover
            logging.warning("KB fetch failed for %s: %s", rhsa, e)
            return None, None

    @staticmethod
    def extract_fixed_nvras(cvrf: dict, component: str, os_release: str = "8") -> List[str]:
        if not cvrf:
            return []
        texts: List[str] = []

        def walk(x: Any) -> None:
            if isinstance(x, dict):
                for v in x.values(): walk(v)
            elif isinstance(x, list):
                for v in x: walk(v)
            elif isinstance(x, str):
                if component in x or f"el{os_release}" in x or "noarch" in x:
                    texts.append(x)
        walk(cvrf)

        rx = re.compile(rf"\b({re.escape(component)})-([0-9][\w\.\+~:-]*)\.el{re.escape(os_release)}\.(\w+)\b")
        out: List[str] = []
        seen = set()
        for t in texts:
            for m in rx.finditer(t):
                nvra = m.group(0)
                if nvra not in seen:
                    out.append(nvra)
                    seen.add(nvra)
        return out

