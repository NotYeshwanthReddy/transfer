#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures

from .models import *
class AIPlanner:
    def __init__(self, model: str = DEFAULT_MODEL, temperature: Optional[float] = 0.0) -> None:
        # Some 'gpt-4o' models reject explicit temperature; omit for those models
        self.model = model
        self.pass_temperature = (temperature is not None) and ("gpt-4o" not in (model or "").lower())
        self.temperature = temperature if self.pass_temperature else None
        if OpenAI is None or not os.getenv("OPENAI_API_KEY"):
            self.client = None
        else:
            self.client = OpenAI()

    def plan(self, row: NormalizedRow, component: str, rhsa: Optional[str],
             kb_nvras: List[str], repo_latest: Optional[str]) -> Dict[str, Any]:
        """
        Call the LLM with strict system prompt + compact context.
        Fallback to deterministic plan if LLM unavailable or API rejects params.
        """
        ctx = {
            "asset": row.asset,
            "env": row.env,
            "component": component,
            "rhsa": rhsa,
            "kb_fixed_nvras": kb_nvras,
            "repo_latest": repo_latest,
            "vuln_name": row.vuln_name,
            "solution_text": row.solution_text,
            "owner": row.owner_hint or "TI – AIX/UNIX Team",
        }

        if self.client is None:
            logging.warning("OpenAI not available; using deterministic fallback plan")
            return self._fallback(ctx)

        try:
            kwargs = {
                "model": self.model,
                "messages": [
                    {"role": "system", "content": PLANNER_SYS_PROMPT},
                    {"role": "user", "content": json.dumps(ctx)},
                ],
                "response_format": {"type": "json_object"},
            }
            if self.pass_temperature and self.temperature is not None:
                kwargs["temperature"] = self.temperature

            msg = self.client.chat.completions.create(**kwargs)
            content = msg.choices[0].message.content  # type: ignore[attr-defined]
            data = json.loads(content)
            return self._coerce(data, ctx)
        except Exception as e:  # pragma: no cover
            logging.error("LLM planning failed: %s", e)
            return self._fallback(ctx)

    @staticmethod
    def _coerce(data: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
        def ensure_list(x: Any) -> List[str]:
            return [str(i) for i in x] if isinstance(x, list) else [str(x)] if isinstance(x, str) else []
        pre = ensure_list(data.get("precheck")) or [
            rf"rpm -qa | egrep '^{re.escape(ctx['component'])}' || true",
            "dnf check-update --security || true",
            "pgrep -a python || true",
        ]
        steps = ensure_list(data.get("steps")) or [
            f"dnf update -y --security{(' --advisory='+ctx['rhsa']) if ctx.get('rhsa') else ''} {ctx['component']}",
        ]
        post = ensure_list(data.get("postcheck")) or [
            f"rpm -q {ctx['component']} --qf '%{{NAME}}-%{{VERSION}}-%{{RELEASE}}.%{{ARCH}}\\n'",
            "needs-restart -r || true",
        ]
        reboot = bool(data.get("reboot_required", False))
        target = str(data.get("target_description") or (
            f"Install the {ctx['rhsa']} fixed build (or newer) from approved repo" if ctx.get("rhsa") else
            "Install the latest security-fixed build from approved repo"
        ))
        note = str(data.get("ticket_note") or "Python setuptools security update per advisory")
        return {"precheck": pre, "steps": steps, "postcheck": post, "reboot_required": reboot, "target": target, "ticket_note": note}

    @staticmethod
    def _fallback(ctx: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "precheck": [
                rf"rpm -qa | egrep '^{re.escape(ctx['component'])}' || true",
                "dnf check-update --security || true",
                "pgrep -a python || true",
            ],
            "steps": [
                f"dnf update -y --security{(' --advisory='+ctx['rhsa']) if ctx.get('rhsa') else ''} {ctx['component']}",
            ],
            "postcheck": [
                f"rpm -q {ctx['component']} --qf '%{{NAME}}-%{{VERSION}}-%{{RELEASE}}.%{{ARCH}}\\n'",
                "needs-restart -r || true",
            ],
            "reboot_required": False,
            "target": (
                f"Install the {ctx['rhsa']} fixed build (or newer) from approved repo" if ctx.get("rhsa") else
                "Install the latest security-fixed build from approved repo"
            ),
            "ticket_note": "Deterministic fallback plan (LLM unavailable)",
        }

