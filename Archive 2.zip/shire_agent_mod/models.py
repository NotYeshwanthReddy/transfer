#!/usr/bin/env python3
"""
Shire - Python Vulnerability Scanner **AI Agent** (Standalone, LangGraph-ready)

Features
- Ingests CSV / Excel / JSON (header-agnostic via aliases)
- Fetches Red Hat CVRF (allowlisted); handles 404 gracefully
- Verifies repo availability with `dnf repoquery` (skips cleanly if dnf absent)
- Uses an LLM Planner (OpenAI) with guardrails; falls back to deterministic plan if LLM unavailable
- Emits per-row plan (YAML/JSON), KB, and coordinator event structures

Env:
  OPENAI_API_KEY=<key>
  SHIRE_MODEL=gpt-4o-mini   # optional (can override via --model)

Quickstart:
  python -m venv .venv && source .venv/bin/activate
  pip install requests pyyaml pandas openai "numpy<2"
  export OPENAI_API_KEY=YOUR_KEY
  python shire_python_ai_agent.py --input sample_findings.csv --out ./out --format yaml json
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Optional deps (kept graceful)
try:
    import pandas as pd  # Excel/CSV convenience (Excel requires pandas)
except Exception:
    pd = None  # type: ignore

try:
    import yaml  # YAML output
except Exception:
    yaml = None  # type: ignore

try:
    import requests
except Exception:
    requests = None  # type: ignore

# OpenAI client (optional; agent will fallback if unavailable)
try:
    from openai import OpenAI  # pip install openai>=1.0.0
except Exception:
    OpenAI = None  # type: ignore

# ------------------------------------
# Allowlisted sources & runtime config
# ------------------------------------
TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}
DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")
DEFAULT_TIMEOUT_S = 20
USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

# ----------------
# Data structures

TRUSTED = {
    "redhat_cvrf": "https://access.redhat.com/hydra/rest/securitydata/cvrf/{rhsa}.json",
    "redhat_errata": "https://access.redhat.com/errata/{rhsa}",
}

DEFAULT_MODEL = os.getenv("SHIRE_MODEL", "gpt-4o-mini")

DEFAULT_TIMEOUT_S = 20

USER_AGENT = "ShireScannerAI/1.0 (+security@example.org)"

COLUMN_ALIASES = {
    "asset": ["asset", "asset name", "hostname", "host", "server"],
    "env": ["env", "environment"],
    "platform": ["platform", "os", "operating system"],
    "vuln_name": ["vuln name", "vulnerability", "vulnerability name", "name"],
    "solution_text": ["solution", "solution text", "remediation", "fix"],
    "owner_hint": ["owner", "treatment owner", "team", "treatment_owner"],
    "sox": ["sox", "sox indicator", "sox_indicator"],
}

DEFAULT_OWNER_OS = "TI – AIX/UNIX Team"

RHSA_RX = re.compile(r"RHSA[-\s:]?\s*(\d{4}:\d{4,5})", re.I)

SETUPTOOLS_PATTERNS = [
    (re.compile(r"python3\.11-setuptools", re.I), "python3.11-setuptools"),
    (re.compile(r"python3-setuptools", re.I), "python3-setuptools"),
    (re.compile(r"python-setuptools", re.I), "python-setuptools"),
]


@dataclass
class NormalizedRow:
    asset: str
    env: Optional[str] = None
    platform: Optional[str] = None
    vuln_name: str = ""
    solution_text: str = ""
    owner_hint: Optional[str] = None
    sox: Optional[bool] = None
    raw: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Verification:
    status: str  # "passed" | "failed"
    reason: Optional[str] = None
    advisory_id: Optional[str] = None
    fixed_nvras: List[str] = field(default_factory=list)
    repo_latest: Optional[str] = None
    meets_or_exceeds_fixed: Optional[bool] = None
    advisory_url: Optional[str] = None
    api_url: Optional[str] = None
    fetched_at_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"))
    payload_sha256: Optional[str] = None

@dataclass
class Plan:
    plan_id: str
    asset: str
    env: Optional[str]
    platform: Optional[str]
    vulnerability: Dict[str, Any]
    owner: str
    action_type: str
    component: str
    target: Dict[str, Any]
    precheck: List[str]
    steps: List[str]
    postcheck: List[str]
    reboot_required: bool
    verification: Verification
    ticket_text: str
    coordinator_event: Dict[str, Any]

